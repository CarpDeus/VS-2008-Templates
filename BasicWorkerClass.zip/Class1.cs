﻿using System;
using System.Collections.Generic;
using System.Text;

using System.Threading;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Xml;
using System.Xml.XPath;
using log4net;
using log4net.Config;


namespace WorkerClass
{
 public class Class1
 {
  /// <summary>
  /// Set to false to stop processing mid-loop
  /// </summary>
  public bool KeepProcessing { get; set; }

  /// <summary>
  /// Used to return back that something is going on
  /// </summary>
  public int ProcessedCount { get; set; }

  /// <summary>
  /// Used for connectivity to the database
  /// </summary>
  public string dbConnection { get; set; }

  /// <summary>
  /// Logging interface
  /// </summary>
  private static log4net.ILog log = null;

  /// <summary>
  /// Initializes the logging
  /// </summary>
  private void InitLog()
  {
   log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
   XmlConfigurator.Configure();
  }

  /// <summary>
  /// Thread for background processing
  /// </summary>
  Thread backgroundThread;


  /// <summary>
  /// Handler for notification back to the client
  /// </summary>
  /// <param name="message"></param>
  public delegate void LogHandler(string message);
  private LogHandler mvLogHandler;

  /// <summary>
  /// Take a message and hand it off to the calling client
  /// if the client has defined a handler.
  /// </summary>
  /// <param name="msgString">Notification message</param>
  public void OnLogHandler(LogHandler msgString)
  {
   if (msgString != null)
    mvLogHandler = msgString;
  }


  /// <summary>
  /// Notification back to the client
  /// </summary>
  /// <param name="msg"></param>
  void NotifyCaller(string msg)
  {
   // This way we don't need to worry about initialization until we go to log
   if (log == null)
    InitLog();
   //  log.ErrorFormat("MemcacheD error getting information: {0}\r\nError: {1}", key, ex.ToString());
   log.InfoFormat(msg);
   // If a delegate has been designated, use it
   if (mvLogHandler != null)
    mvLogHandler(msg);
   else Console.WriteLine(msg);
  }

  /// <summary>
  /// Create a new instance
  /// </summary>
  public Class1()
  {
   Initialize();
  }

  /// <summary>
  /// Create a new instance and initialize the database connection
  /// </summary>
  /// <param name="DBConnection">Database cionnection string</param>
  public Class1(string DBConnection)
  {
   dbConnection = DBConnection;
   Initialize();
  }

  /// <summary>
  /// Class initialization
  /// </summary>
  public void Initialize()
  {
   if (dbConnection == string.Empty)
   {
    // throw error
   }
   else
   {
   }
  }

  /// <summary>
  /// Start processing on a background thread
  /// </summary>
  public void StartProcessing()
  {
   KeepProcessing = false;
   backgroundThread = new Thread(new ThreadStart(ProcessData));
   backgroundThread.Start();
  }
  
  /// <summary>
  /// Process data without using a thread
  /// </summary>
  public void ProcessData()
  {
   ProcessedCount = 0;
   KeepProcessing = true;
   while (KeepProcessing)
   {
    // Do something
   }
  }

 }
}
