﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.ServiceProcess;
using System.Text;

using WorkerClass;
using System.Timers;
using log4net;

namespace $safeprojectname$
{
 public partial class Service1 : ServiceBase
 {
  /// <summary>
  /// Timer for processing
  /// </summary>
  Timer timer1 = new Timer();

  /// <summary>
  /// Worker class where all real code is stored
  /// </summary>
  WorkerClass.Class1  wc = new  Class1($safeprojectname$.Properties.Settings.Default.dbConnection);

  /// <summary>
  /// Logging interface
  /// </summary>
  private static log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

  /// <summary>
  /// Handle notifications back from worker class
  /// </summary>
  /// <param name="Notification">Message</param>
  public void Notify(string Notification)
  {
   log.Info(Notification);
  }


  /// <summary>
  /// Service Creation
  /// </summary>
  public Service1()
  {
   InitializeComponent();
   // Initialize the worker class
   wc.Initialize();
   // Configure logging
   log4net.Config.XmlConfigurator.Configure();
   // Set the timer
   timer1.Interval = $safeprojectname$.Properties.Settings.Default.TimerInterval;
   timer1.Enabled = false;
   timer1.Elapsed += new ElapsedEventHandler(timer1_Tick);

  }

  /// <summary>
  /// Start processes
  /// </summary>
  /// <param name="args"></param>
  protected override void OnStart(string[] args)
  {
   timer1.Enabled = true;
   Notify("Started service");
  }


  /// <summary>
  /// Stop the timer
  /// </summary>
  protected override void OnStop()
  {
   // Stop the timer and log
   timer1.Enabled = false;
   Notify("Stopped service");
  }

  /// <summary>
  /// Start a paused service
  /// </summary>
  protected override void OnContinue()
  {
   // Base service continuation
   base.OnContinue();
   // Notify log
   Notify("Continued service");

   // Start timer
   timer1.Enabled = true;

  }

  /// <summary>
  ///  Service paused
  /// </summary>
  protected override void OnPause()
  {
   // Base service pause
   base.OnPause();
   // Disable timer
   timer1.Enabled = false;
   // Notify log
   Notify("Paused service");
  }

  /// <summary>
  /// Service shutdown request
  /// </summary>
  protected override void OnShutdown()
  {
   // Base service shutdown 
   base.OnShutdown();
   // Disable timer
   timer1.Enabled = false;
   // Log
   Notify("Shutdown service");
  }


  private void timer1_Tick(object sender, EventArgs e)
  {
   timer1.Enabled = false;
   /*
   // For non-threaded processing use this block and comment out
   // the rest of the method
   wc.ProcessData();
   Notify(string.Format("Processed {0} records", wc.ProcessedCount));
   timer1.Enabled = true;


    */
   int Processed = wc.ProcessedCount;
   if (wc.KeepProcessing)
   {
    Notify(string.Format("Background Thread processing at {0} / Processed {1} records", DateTime.Now.ToLongTimeString(), wc.ProcessedCount));
   }
   else
   {
    wc.StartProcessing();
    Notify(string.Format("Kicked off background thread processor {0} / Last round processed {1} records", DateTime.Now.ToLongTimeString(), Processed));
   }
   timer1.Enabled = true;
  }
 }
}
