﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using System.Timers;

using WorkerClass;

namespace BasicApplicationService
{
 public partial class Form1 : Form
 {

  /// <summary>
  /// Timer for processing
  /// </summary>
  System.Timers.Timer timer1 = new System.Timers.Timer();

  /// <summary>
  /// Worker Class
  /// </summary>
  WorkerClass.Class1 wc = new Class1(Properties.Settings.Default.DBConnection );

  /// <summary>
  /// Handle background thread notifications
  /// </summary>
  /// <param name="Message"></param>
  delegate void NotifyCallback(string Message);



  public Form1()
  {
   InitializeComponent();
   timer1.Interval = 5000;
   timer1.Elapsed += new ElapsedEventHandler(timer1_Tick);
   timer1.Enabled = true;
   wc.Initialize();
   wc.OnLogHandler(Notify);
  }

  /// <summary>
  /// Process events on the timer
  /// </summary>
  /// <param name="sender"></param>
  /// <param name="e"></param>
  private void timer1_Tick(object sender, EventArgs e)
  {
   // Disable the timer so it doesn't go off again while we are processing
   timer1.Enabled = false;
   // Display hourglass 
   this.Cursor = Cursors.WaitCursor;
   // Get processed count from class, could be working on a background thread
   int Processed = wc.ProcessedCount;

   // If the class is in KeepProcessing mode then it is doing work on a background thread
   if (wc.KeepProcessing)
   {
    // Get information from the class and update the form
    toolStripStatusLabel1.Text = string.Format("Background Thread processing at {0} / Processed {1} records", DateTime.Now.ToLongTimeString(), wc.ProcessedCount);
   }
   else // Not currently processing
   {
    // Kick off processing
    wc.StartProcessing();
    // Update form
    toolStripStatusLabel1.Text = string.Format("Kicked off background thread processor {0} / Last round processed {1} records", DateTime.Now.ToLongTimeString(), Processed);
   }
   // Refresh everything
   Application.DoEvents();
   // Rest the cursor
   this.Cursor = Cursors.Default;
   // Enable the timer
   timer1.Enabled = true;
  }

  /// <summary>
  /// Relay notications from the worker class
  /// </summary>
  /// <param name="Message">Notification</param>
  private void Notify(string Message)
  {
   // InvokeRequired required compares the thread ID of the
   // calling thread to the thread ID of the creating thread.
   // If these threads are different, it returns true.
   if (this.textBox1.InvokeRequired)
   {
    NotifyCallback d = new NotifyCallback(Notify);
    this.Invoke(d, new object[] { Message });
   }
   else
   {
    this.textBox1.Text = Message;
   }
   Application.DoEvents();
  }

  // Just run through the process in the worker class without threading
  private void button1_Click(object sender, EventArgs e)
  {
   wc.ProcessData();
  }

  // When checked, enable the timer
  private void checkBox1_CheckedChanged(object sender, EventArgs e)
  {
   timer1.Enabled = checkBox1.Checked;
   button2.Enabled = checkBox1.Checked;
  }

  // Set background thread processing flag to false
  private void button2_Click(object sender, EventArgs e)
  {
   wc.KeepProcessing = false;
  }

 }
}
